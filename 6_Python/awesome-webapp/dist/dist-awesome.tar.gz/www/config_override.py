#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
Override configurations.
'''

__author__ = 'Steven'

configs = {
    'db' : {
        'host': '192.168.31.10'
    }
}